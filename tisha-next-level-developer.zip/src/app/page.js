"use client"
import axios from "axios";
import { useContext, useEffect, useState } from "react";
import { TishaContext } from "./layout";
import { useRouter } from "next/navigation";


export default function Home() {
  let [user, setUser] = useState({})
  let [products, setProducts] = useState([])
  const [currentPage, setCurrentPage] = useState(1);
  let [total, setTotal] = useState(0)
  const router = useRouter();
  let getAllProducts = async () => {
    let response = await axios.get(`https://dummyjson.com/products?limit=10&skip=${(currentPage - 1) * 10}`)
    setProducts(response.data.products)
    setTotal(response.data.total)
    console.log(response.data)
  }
  useEffect(() => {
    getAllProducts()
    setUser(JSON.parse(localStorage.getItem('user')))
  }, [currentPage])

  const pagenationItems = () => {
    const newArr = [];
    newArr.push(<button className="px-4 py-2  border" style={{ display: currentPage <= 1 && 'none' }} onClick={() => setCurrentPage(currentPage - 1)}>
      {'<'}
    </button>)
    for (let i = 1; i <= Math.ceil(total / 10); i++) {
      newArr.push(
        <button className="px-4 py-2 border" style={{ background: currentPage == i && 'blue' }} key={i} onClick={() => setCurrentPage(i)}>
          {i}
        </button>
      );
    }
    newArr.push(<button className="px-4 py-2  border" style={{ display: currentPage >= total / 10 && 'none' }} onClick={() => setCurrentPage(currentPage + 1)}>
      {'>'}
    </button>)
    return newArr;
  };
  let { getCart } = useContext(TishaContext)

  let AddToCartHandler = (product) => {
    let oldCart = JSON.parse(localStorage.getItem('cart')) || [];
    let newCart = [...oldCart, product]
    localStorage.setItem('cart', JSON.stringify(newCart))
    router.push('/cart');
    getCart()
  }
  return (
    <>
      <div className="grid grid-cols-12 gap-4 p-12">
        {
          products.map((x) => {
            return <div className="col-span-3 shadow p-3 ">
              <img src={x.thumbnail} />
              <h2 className="my-2">{x.title}</h2>
              <h3 className="my-2">₹{x.price}</h3>
              <button onClick={() => AddToCartHandler(x)} className="bg-black text-white px-4 py-1 rounded-sm">Add To Cart</button>
            </div>
          })
        }
      </div >
      <div className="pagenation">
        {products.length && pagenationItems()}
      </div>
    </>
  );
}