import Link from 'next/link'
import React from 'react'

const Header = () => {
    return (
        <div className='flex items-center px-12 h-[80px] gap-12 bg-black text-white'>
            <p><Link href={'/'}>Home</Link></p>
            <p><Link href={'/about'}>About</Link></p>
            <p><Link href={'/register'}>Register</Link></p>
            <p><Link href={'/login'}>Login</Link></p>
        </div>
    )
}

export default Header
