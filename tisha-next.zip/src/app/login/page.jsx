import React from 'react'

const page = () => {
    return (
        <div>
            login
        </div>
    )
}

export default page
