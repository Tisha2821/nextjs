'use client'
import React, { useContext } from 'react'
import { TishaContext } from '../layout'

const page = () => {
    let { cart } = useContext(TishaContext)
    return (
        <div>
            <div className="grid grid-cols-12 gap-4 p-12">
                {
                    cart.map((x) => {
                        return <div className="col-span-3 shadow p-3 ">
                            <img src={x.thumbnail} />
                            <h2 className="my-2">{x.title}</h2>
                            <h3 className="my-2">₹{x.price}</h3>
                            <button onClick={() => AddToCartHandler(x)} className="bg-black text-white px-4 py-1 rounded-sm">Add To Cart</button>
                        </div>
                    })
                }
            </div >
        </div>
    )
}

export default page
