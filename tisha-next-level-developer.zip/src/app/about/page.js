import React from 'react'

const page = () => {
    return (
        <div>
            <h1>helo form aboout</h1>
        </div>
    )
}

export default page
