"use client"
import { useEffect, useState } from "react";

export default function Home() {
  let [user, setUser] = useState({})

  useEffect(() => {
    setUser(JSON.parse(localStorage.getItem('user')))
  }, [])
  return (
    <>
      <h1>hello {user.username}</h1>
    </>
  );
}